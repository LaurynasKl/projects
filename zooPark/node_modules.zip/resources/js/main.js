import 'bootstrap';

console.log('main.js');